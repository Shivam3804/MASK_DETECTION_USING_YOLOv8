# Face Mask Detection  > 2023-10-10 11:42am
https://universe.roboflow.com/uk-zychs/face-mask-detection-oryic

Provided by a Roboflow user
License: CC BY 4.0

